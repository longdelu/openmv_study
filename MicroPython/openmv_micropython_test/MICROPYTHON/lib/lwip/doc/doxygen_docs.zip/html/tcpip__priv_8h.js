var tcpip__priv_8h =
[
    [ "tcpip_api_call", "tcpip__priv_8h.html#a3d42b0c46607f91aedcc7745ed466b08", null ],
    [ "tcpip_send_msg_wait_sem", "tcpip__priv_8h.html#a12bdf37eddcd72c4178e3ea7d370395d", null ]
];